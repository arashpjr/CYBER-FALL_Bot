const settings = {
  packname: '𝐂ꌩ𝐁ᗴ𝐑-𝐅ᗩ𝐋𝐋',
  author: '‎',
  botName: "𝐂ꌩ𝐁ᗴ𝐑-𝐅ᗩ𝐋𝐋",
  botOwner: 'C F. A RASH_404', // Your name
  ownerNumber: '93700495877', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.4",
  updateZipUrl: "https://github.com/arashpjr/CYBER-FALL_Bot/archive/refs/heads/main.zip",
};

module.exports = settings;
